import React from "react";
import { FaUserGraduate, FaBook, FaCalendarAlt, FaSignOutAlt } from "react-icons/fa";
import "./StudentDashboard.css";

const StudentDashboard = () => {
  return (
    <div className="student-dashboard">
      <h1>Welcome to Student's Dashboard</h1>
      <div className="dashboard-container">
        <div className="dashboard-card">
          <FaUserGraduate className="dashboard-icon" />
          <h3>Profile</h3>
          <p>View and update your personal details.</p>
        </div>
        <div className="dashboard-card">
          <FaBook className="dashboard-icon" />
          <h3>Courses</h3>
          <p>Check your enrolled courses and progress.</p>
        </div>
        <div className="dashboard-card">
          <FaCalendarAlt className="dashboard-icon" />
          <h3>Schedule</h3>
          <p>View your class schedule and upcoming events.</p>
        </div>
        <div className="dashboard-card logout">
          <FaSignOutAlt className="dashboard-icon" />
          <h3>Logout</h3>
          <p>Sign out of your student account.</p>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
