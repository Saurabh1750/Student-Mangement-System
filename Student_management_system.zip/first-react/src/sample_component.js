import React from 'react';
function Outside(){
  return <div><h1>This is my external component</h1></div>
}

export default Outside
