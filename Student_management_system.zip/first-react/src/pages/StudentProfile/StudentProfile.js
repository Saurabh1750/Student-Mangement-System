import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { userRows } from "../../DummyData"; 
const StudentProfile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const studentData = userRows.find((student) => student.id === parseInt(id));

  const [student, setStudent] = useState(studentData || { fullName: "", email: "", phone: "" });

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Student Updated Successfully!");
    navigate("/students");
  };

  return (
    <div>
      <h2>Edit Student</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="fullName" value={student.fullName} onChange={handleChange} required />
        <input type="email" name="email" value={student.email} onChange={handleChange} required />
        <input type="text" name="phone" value={student.phone} onChange={handleChange} required />
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
};

export default StudentProfile;
