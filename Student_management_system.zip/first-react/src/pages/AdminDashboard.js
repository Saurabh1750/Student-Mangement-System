import React from "react";
import "./AdminDashboard.css";
import { FaUserGraduate, FaUsers, FaBook, FaCog } from "react-icons/fa";

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard">
      <h1 className="welcome-text">WELCOME TO ADMIN'S DASHBOARD</h1>

      <div className="dashboard-container">
        <div className="dashboard-card">
          <FaUserGraduate className="dashboard-icon" />
          <h3>Manage Students</h3>
          <p>Add, Edit, or Remove Students</p>
        </div>

        <div className="dashboard-card">
          <FaUsers className="dashboard-icon" />
          <h3>Manage Teachers</h3>
          <p>Assign, Edit, or Remove Teachers</p>
        </div>

        <div className="dashboard-card">
          <FaBook className="dashboard-icon" />
          <h3>Manage Classes</h3>
          <p>Set up and update class schedules</p>
        </div>

        <div className="dashboard-card">
          <FaCog className="dashboard-icon" />
          <h3>Settings</h3>
          <p>Customize system preferences</p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
