import React,{useState} from 'react'

function SampleCode(props){
    return<h1> Hello {props.name} welcome to the React App. Your age is = {props.age}</h1>
}

function Second(props)
{
  var  [num,changenum]=useState(0)
    return <h1> {num} <button onClick={()=>{changenum(num++)}}> Click me</button></h1>
}

function Third(){

}


export default SampleCode
export {Second,Third}


