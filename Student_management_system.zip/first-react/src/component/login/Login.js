import React from 'react';
import { Link } from 'react-router-dom';
import './Login.css';

function Login() {
  return (
    <div className="login-container">
      <h1>Excellence Management System</h1>
      <div className="login-flex">
        
        {/* Student Login */}
        <div className="login-box">
          <h2>Student</h2>
          <span>Excellence Management System</span>
          <div>
            <label>Username:</label>
            <input type="text" placeholder="Enter Username" />
          </div>
          <div>
            <label>Password:</label>
            <input type="password" placeholder="Enter Password" />
          </div>
          <Link to="/student-dashboard">
            <button className="login-btn">Login</button>
          </Link>
        </div>

        {/* Admin Login */}
        <div className="login-box">
          <h2>Admin</h2>
          <span>Excellence Management System</span>
          <div>
            <label>Username:</label>
            <input type="text" placeholder="Enter Username" />
          </div>
          <div>
            <label>Password:</label>
            <input type="password" placeholder="Enter Password" />
          </div>
          <Link to="/admin-dashboard">
            <button className="login-btn">Login</button>
          </Link>
        </div>

      </div>
    </div>
  );
}

export default Login;
