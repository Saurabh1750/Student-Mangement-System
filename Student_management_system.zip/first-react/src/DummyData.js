export const userRows = [
  { id: 1, userName: 'Jon Snow', avatar: 'https://th.bing.com/th/id/OIP.DQKdYA6bYTWSePGcAyofpgHaHa?w=158&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7', email: 'jon.snow@gmail.com' },
  { id: 2, userName: 'Arya Stark', avatar: 'https://images.pexels.com/photos/1386604/pexels-photo-1386604.jpeg', email: 'arya.stark@gmail.com' },
  { id: 3, userName: 'Tyrion Lannister', avatar: 'https://th.bing.com/th/id/OIP.zLj7r6a_VuO2dMY8wdWzLQAAAA?w=188&h=282&c=7&r=0&o=5&dpr=1.3&pid=1.7', email: 'tyrion.lannister@gmail.com' },
  { id: 4, userName: 'Daenerys Targaryen', avatar: 'https://th.bing.com/th/id/OIP._rD9bGqU5yGBb6BfqfvoCwHaLI?w=202&h=304&c=7&r=0&o=5&dpr=1.3&pid=1.7', email: 'daenerys@gmail.com' },
  { id: 5, userName: 'Bran Stark', avatar: 'https://th.bing.com/th/id/OIP.IGNf7GuQaCqz_RPq5wCkPgHaLH?w=202&h=303&c=7&r=0&o=5&dpr=1.3&pid=1.7', email: 'bran.stark@gmail.com' }
];
