import React, { useState } from "react";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Topbar from "./component/Topbar/Topbar";
import SideBar from "./component/SideBar/SideBar";
import "./App.css";
import Home from "./pages/home/Home";
import StudentList from "./pages/studentList/StudentList";
import NewStudent from "./pages/NewStudent/NewStudent";
import Login from "./component/login/Login";
import StudentProfile from "./pages/StudentProfile/StudentProfile";
import { userRows } from "./DummyData"; 
import AdminDashboard from "./pages/AdminDashboard";
import StudentDashboard from "./pages/StudentDashboard";


function App() {
  const [students, setStudents] = useState(userRows);

  const handleDelete = (id) => {
    setStudents(students.filter((student) => student.id !== id));
  };

  return (
    <BrowserRouter>
      <Topbar />
      <div className="container">
        <SideBar />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/login" element={<Login />} />
          <Route path="/students" element={<StudentList students={students} handleDelete={handleDelete} />} />
          <Route exact path="/newstudent" element={<NewStudent />} />
          <Route exact path="/student/:id" element={<StudentProfile />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/student-dashboard" element={<StudentDashboard/>} />

         
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;